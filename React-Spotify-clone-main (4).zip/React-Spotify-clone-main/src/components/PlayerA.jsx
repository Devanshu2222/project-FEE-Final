import React from 'react'

const PlayerA = () => {
  return (
    <>
    </>
  )
}

export default PlayerA